
import org.junit.Test;
import org.junit.Assert;

public class ObjectMapperTest {
	
	ObjectMapper obj = new ObjectMapper();
	
	@Test
	public void test_string_are_quoted_in_json() {
		// Given
		// When
		String res = obj.object2Json("Hello");
		// Then
		Assert.assertEquals("\"Hello\"", res);
	}
	
	@Test
	public void test_int_are_written_as_is_in_json() {
		// Given
		// When
		String res = obj.object2Json(456);
		// Then
		Assert.assertEquals("456", res);
	}
	
	@Test
	public void test_boolean_are_literal_in_json() {
		// Given
		// When
		String res = obj.object2Json(false);
		// Then
		Assert.assertEquals("false", res);
	}
	
	@Test
	public void test_curly_are_literal_in_json() {
		// Given
		// When
		String res = obj.object2Json(false);
		// Then
		Assert.assertEquals("false", res);
	}

	@Test
	public void test_int_value_is_recognized_in_json() {
		//Given
		//When
		Integer res =  obj.json2Object("123", Integer.class);
		Assert.assertEquals(Integer.valueOf(123), res);
	}
	

	 @Test
	public void test_string_value_is_recognized_in_json() {
		//Given
		//When
		String res = obj.json2Object("Hello", String.class);
		// Then
		Assert.assertEquals("\"Hello\"", res);
	}

	class Animal {
		public String name;
	}
	@Test
	public void test_object_value_is_recognized_in_json() {
		//Given
		//When
		Animal res = obj.json2Object("Hello", Animal.class);
		// Then
		Assert.assertEquals("Hello", res.name);
	}
}
