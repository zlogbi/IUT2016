

public class Author {
	
	public String firstName; 
	public String LastName; //public psk sinon on peut pas y acceder que par les get et set
	
}
