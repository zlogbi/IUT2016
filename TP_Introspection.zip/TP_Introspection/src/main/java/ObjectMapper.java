import java.lang.reflect.Field;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;

public class ObjectMapper {

		
	public String object2Json(Object value) {
		StringBuilder sb = new StringBuilder();
		object2Json(value, sb);
		return sb.toString();	
	}
	

	private void object2Json(Object value, StringBuilder sb) { //source et dest en parametre
		if (value == null) {
			sb.append("null"); 
		} else if(value instanceof Integer) {
			Integer v = (Integer) value;
			sb.append(Integer.toString(v));	
		} else if(value instanceof String)  {
			sb.append("\"" + value + "\"");
		} else if (value instanceof Boolean)  {
			boolean v = (Boolean) value; 
			sb.append(v? "true" : "false");

		} else {
			object2Json_Object(value, sb); //recursion
		}
	}
		
	protected void object2Json_Object(Object anyObject, StringBuilder sb) { //source et dest en parametre
		sb.append("{ ");
		Class clss = anyObject.getClass();
		Field[] fields = clss.getFields();
		for(int i = 0; i < fields.length; i++) {
			Field f = fields[i];
			Object fieldValue;  
			try {
				fieldValue = f.get(anyObject);
			} catch (IllegalArgumentException | IllegalAccessException e) {
				continue; //TODO
			} 
			sb.append("\"" + f.getName() + "\" : ");
			object2Json(fieldValue, sb);
		} sb.append(" }");
	}

	public <T> T json2Object(String string, Class<T> clss) {
		return null;
	}
	
	/*private void object2Json(Collections ls, String str) { //source et dest en parametre
		
		HashSet hs = new HashSet();
		Iterator it = hs.iterator();
		System.out.println(it.next());
        Object[] obj = hs.toArray();
        for(Object o : obj)
        System.out.println(o);  
		
	}*/
}
	
