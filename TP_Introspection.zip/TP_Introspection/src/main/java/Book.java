

public class Book {
	
	//@Data
	public String title;
	public int pageCount;
	public Author[] author;
	
}
